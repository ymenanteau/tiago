MatrixXf m;
m.setConstant(3, 3, 5);
cout << m << endl;
